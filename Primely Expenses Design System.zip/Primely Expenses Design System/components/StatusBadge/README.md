# StatusBadge

Shows a claim's workflow status as icon + text + colour, so it never depends on colour alone.

- Markup: `<span class="pe-badge pe-badge-{draft|submitted|needs-info|resubmitted|approved|rejected|paid|withdrawn}">` containing an `aria-hidden` 16px icon followed by the label.
- Labels follow the status vocabulary in the README. In the employee view, Needs information reads "Needs your input". Approved always reads "Approved · not paid" until payment is recorded.
- "Paid" is only shown after a finance user records payment. It never means the app sent money.
- In tables, pair the badge with a next-action line in `pe-muted` where one exists (for example "Reply by 14 Nov", but only if a due period is configured).

# ConfirmDialog

A modal that confirms a consequential status change before it is saved: approve, reject, request information, record payment or withdraw.

- The title asks the question with the claim reference ("Reject EXP-2026-00142?"). The body says what will happen and who will see it.
- Reject and Request information require a reason, and the confirm button stays disabled until one is entered. Record payment asks for the payment date (required), the method and an optional transaction reference, and its wording says this records a payment made outside the app.
- If the processor is also the claimant, show the self-processing warning, unless Primely has configured self-approval as acceptable.
- Cancel comes first and the action last. The confirm button uses the action's tone (danger for reject or withdraw, primary otherwise). Focus starts in the first field, or on Cancel when there is no field. Esc cancels, and focus returns to the button that opened the dialog.

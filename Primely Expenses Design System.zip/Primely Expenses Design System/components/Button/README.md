# Button

Buttons start with a verb and use sentence case. Use only one primary button per view.

- `pe-btn` (default, secondary), `pe-btn-primary` (the thing the page is for: "Submit claim", "Approve", "Record payment"), `pe-btn-danger` (Reject, Withdraw, Delete draft), and `pe-btn-quiet` (row actions like "View").
- Consequential actions (Approve, Reject, Request information, Record payment, Withdraw) open a confirmation dialog. Reject and Request information require a reason before the confirm button is enabled.
- Disabled buttons need a visible reason nearby ("Tick the declaration to submit"). Buttons are at least 40px tall and show the `primely-navy` focus outline.

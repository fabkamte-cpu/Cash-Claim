# AppShell

The page frame: a navy top bar, a role-aware side navigation and the main content area.

- Structure: `div.pe-shell` containing `header.pe-topbar`, `nav.pe-sidenav[aria-label=Main]`, `main.pe-main` and `nav.pe-bottombar`. The bottom bar is shown only under 768px.
- The top bar holds the Primely logo (white or `on-primary` version, once supplied) and the signed-in user's name. Until the logo arrives, it shows the "Primely" text brand.
- The current page uses `aria-current="page"`, which gets a navy-soft fill and a 3px inset navy edge. Counts (`pe-count`) say how many items wait, toned by status family, and are always numbers, never dots.
- Sections render by role. Employees see My claims, New claim, Receipts, Drafts, Needs your input and Reports. Finance also gets Finance queue. Admins also get Settings and Audit log. The server enforces access; hiding links is only a convenience.
- The top bar uses `brand-bar` and `on-brand-bar`, which stay deep navy in dark mode too. It does not use `primely-navy`, which lightens in dark mode so links stay readable.
- Every page needs `<meta name="viewport" content="width=device-width, initial-scale=1">`. Without it, phones render the 980px desktop layout.
- On mobile, the bottom bar keeps the four most-used destinations, with the rest under More. Add a skip link to `main` as the first focusable element.

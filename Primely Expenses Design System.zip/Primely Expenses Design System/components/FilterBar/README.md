# FilterBar

Search and filters above a `ClaimTable`, with the active filters shown as removable chips.

- Visible by default: Search, Status, From/To dates and Project/site. "More filters" adds Employee (finance only), Category, Amount range and Reference.
- Each active filter that isn't visible in the bar becomes a chip whose `aria-label` reads "Remove filter: …". The result line says how many claims match and whether rejected or withdrawn claims are included. That line is `aria-live`, so screen readers announce changes.
- Exports use exactly these filters. The export file states its export date and the applied filters.

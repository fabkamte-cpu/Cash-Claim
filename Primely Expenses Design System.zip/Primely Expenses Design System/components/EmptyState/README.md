# EmptyState

What a list or panel shows when it has nothing to show. It explains why the list is empty and offers the single next step.

- The wing-stripe motif (`pe-wings`, three tapered bars on each side) is drawn in `primely-navy` and `primely-navy-soft`. It is decorative and `aria-hidden`.
- Heading: state the fact ("No claims awaiting review"). Body: say why, including whether filters hide anything. One button: the next step ("New expense claim", "Clear filters").
- Never use an empty state to hide an error. Failures use an error banner that names what failed.

# StatusCountList

A dashboard panel listing claim counts and totals by status. Each row links to the filtered claim list.

- Each row has a `StatusBadge`, a count, and the total for that status. The whole row is the link, so the keyboard target is large.
- Employee rows, in order: Draft, Needs your input, Awaiting finance (Submitted + Resubmitted), Approved · not paid, Paid. Rejected and Withdrawn are listed when non-zero. Finance shows the queue equivalents.
- Zero rows stay visible, so people can see that nothing is waiting. The panel's one primary action is "New expense claim" for employees, or none for finance.

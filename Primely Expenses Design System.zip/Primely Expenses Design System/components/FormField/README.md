# FormField

A labelled input with its helper text, error message, OCR suggestion or configuration flag.

- Structure: `div.pe-field` containing a `label.pe-label[for]`, an `input.pe-input`, and one message linked with `aria-describedby`.
- Errors set `aria-invalid="true"`, which adds a thicker `status-rejected` border, and give a `pe-error` message saying how to fix the problem. On submit, also show an error summary at the top that links to each field.
- OCR values use `pe-suggest`: "Suggested from receipt (low/medium/high confidence). Check this." The field stays editable, and the claim cannot be submitted until the employee confirms the item.
- A field whose rule isn't set by Primely shows the `ConfigFlag`, for example a mileage rate. The app never calculates a figure from a guessed value.

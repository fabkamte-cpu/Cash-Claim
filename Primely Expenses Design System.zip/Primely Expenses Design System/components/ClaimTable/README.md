# ClaimTable

A sortable list of claims, used for an employee's "My claims" and for the finance queue.

- Employee columns: Status, Reference, Report date, Project/site, Total, Action. Finance adds Employee as its second column and can filter by employee, status, date range, category, amount, project/site and reference.
- Sortable headers are `<button class="pe-th-sort">` inside `th` with `aria-sort`. The table caption states the date range, active filters and sort, and those same filters are written into exports.
- The row action names the next step: "Respond" when the claim needs the employee's input, otherwise "View".
- Amounts are right-aligned with tabular figures. References use `pe-ref` mono.
- Under 640px, render each row as a stacked card (badge and amount on the first line, reference and date on the second). Don't scroll the table sideways.
- Rejected and withdrawn claims are never silently hidden. Filters say explicitly when they exclude them.

# ConfigFlag

Marks a policy value that Primely hasn't set yet, so the app never silently guesses one.

- Inline: `span.pe-config` reading exactly "Needs Primely configuration", used beside settings, form fields and report totals that depend on the missing value.
- Banner: `div.pe-config-banner[role=note]` for blocking or workflow-wide gaps (approval routing, evidence rules, retention). It says what the app will do meanwhile and links to Settings for administrators only.
- Applies to: mileage rates, VAT requirements, evidence thresholds, approval routing and self-approval, payment terms, query due periods, retention and deletion, and company branding.
- Violet `config-flag` is reserved for this purpose. Don't use it for claim statuses or general warnings.

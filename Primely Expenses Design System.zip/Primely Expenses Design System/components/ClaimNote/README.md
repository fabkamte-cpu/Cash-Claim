# ClaimNote

A message on a claim. Its heading always says who can read it.

- Employee-visible (`pe-note`) is the default: requests for information, rejection reasons and employee replies.
- Finance-only (`pe-note pe-note-private`) uses a sunken, dashed panel headed "Finance only. Not visible to the employee." with a lock icon. Never render it in employee views or exports.
- When composing, finance chooses visibility explicitly with a two-option control. Neither option is preselected when the composer opens on the review page.

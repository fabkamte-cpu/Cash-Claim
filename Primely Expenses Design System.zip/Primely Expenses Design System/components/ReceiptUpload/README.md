# ReceiptUpload

Adds one or more receipt files to an expense item, showing progress, a preview, removal and warnings.

- The drop zone is a keyboard-focusable label around a hidden `input[type=file][multiple]`. On mobile, offer the camera too.
- Each file row shows its name, a progress bar (`role=progressbar` with a value) and Preview/Remove until the claim is submitted.
- Warnings use `pe-warn` in `status-action` tone and never block silently. They cover possible duplicates, unreadable images and missing evidence where Primely's evidence rule requires it. Warn, and let the person explain; never delete or reject automatically.
- Size limits and evidence rules come from Settings. Show the `ConfigFlag` when they are unset.
- Files are served only through access-checked links. Never display a public or guessable URL.

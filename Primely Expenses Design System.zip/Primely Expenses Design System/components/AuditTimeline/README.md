# AuditTimeline

A newest-first, read-only list of a claim's status changes and material edits.

- Each entry shows the event, the transition ("Submitted → Needs information"), the timestamp, the actor with their role, and any employee-visible reason or comment.
- Employees see their own claim's history without finance-only notes. Finance and admin see the same events plus edit details ("Item 2 amount changed £18.00 → £21.50").
- Use an ordered list (`ol.pe-timeline`). Entries can't be edited or deleted in the UI.

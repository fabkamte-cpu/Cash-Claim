# SummaryTile

A dashboard figure with its definition always visible, so totals like "pending" are never ambiguous.

- Structure: `section.pe-tile.pe-tile-{paid|review|total|action}` containing a label, an amount (`pe-tile-amount`, tabular figures) and a one-line definition (`pe-tile-def`).
- The coloured top edge matches the status family it sums. The label still carries the meaning without colour.
- Every definition states what is included and excluded. Totals respect the selected date range, and the range is shown above the tile row.
- Finance uses the same tile for queue counts. In that case, show the count and the total ("12 claims · £4,310.00").

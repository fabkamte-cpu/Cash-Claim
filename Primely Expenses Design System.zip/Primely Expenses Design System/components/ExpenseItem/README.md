# ExpenseItem

One line of a claim, laid out as a card of `FormField`s. Variants cover a standard expense, mileage and a split or mixed-purpose expense.

- The header shows the item number, category and running amount, plus Remove while the claim is a draft. The body is a responsive grid of fields, followed by a `ReceiptUpload`.
- Standard fields: date, category (from the admin list), merchant, business purpose, amount and currency, VAT (optional unless Primely configures it as required) and payment method.
- Mileage fields: from, to, journey purpose, distance and unit. The calculation row (`pe-item-calc`) shows distance × configured rate. When no rate is set it shows the `ConfigFlag` and a dash, and never a guessed total.
- Split or mixed purpose: add a "Business portion" amount and a required explanation field.
- After a query, items the employee changed are marked "Edited after query" so finance can see what changed. The audit log records the details.

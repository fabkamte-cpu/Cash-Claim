# Primely Expenses — design system

The interface for Primely Ltd's internal expense-claims app, used by employees who submit claims and by the finance team who review and pay them. Employees use it in the office, while travelling and on UXO survey sites, often on a phone. Finance uses it at a desk to clear a queue. The design aims to be calm, plain and exact. It should always make the claim's state and the next action obvious.

## The Primely brand

Primely's mark is a single-colour deep navy emblem: a star with three tapered wing stripes on each side, a bomb-tail fin above and a drop below. Below the emblem sits a wide, squared, all-caps PRIMELY wordmark and the line "Unexploded Ordnance (UXO) Specialist". Everything here takes its cues from it:

- **One brand colour.** `primely-navy` (#1E1B38) is the logo's ink. It is used for the app header, primary actions, links and focus. The rest of the UI is white and cool neutrals. Status colours are functional, never decorative.
- **Wing stripes.** The emblem's tapered horizontal bars are the only brand motif. Use them on the cover, the sign-in screen and empty states, never behind data.
- **Precise and squared.** Corners stay small (`radius-sm` to `radius-lg`), with no pills or soft shadows.

> **Still needed from Primely.** The colour value was sampled by eye from the supplied image, so confirm it against the brand guide. The logo is not in this system yet. A clean SVG or high-resolution PNG of the current navy logo (not the older blue "UXO Mitigation Specialist" version) is needed before it can be added under `assets/Logos/`. The wordmark's squared display face isn't available as a font file, so the UI uses the system sans and the wordmark appears only as the logo image. Until the logo is added, the header shows "Primely" in `heading-2` on `primely-navy`.

## Content fundamentals

- **Plain UK English.** Sentence case everywhere ("New expense claim", not "New Expense Claim"). UK spelling ("authorised", "colour"). Dates are `9 Nov 2026` in tables and `09/11/2026` in exports. Amounts are written `£1,240.50` with tabular figures.
- **Name the next action, not the system state.** Write "Answer finance's question and resubmit", not "Status: RFI".
- **Define finance words where they appear.** Each summary tile has a one-line definition under its figure. Examples: "Awaiting review or payment: submitted, resubmitted or approved, not yet paid. Excludes drafts and rejected claims."
- **Never overclaim.** "Payment recorded" means a finance user entered payment details; the app does not move money. Write "Paid · recorded 12 Nov 2026 by A. Finance", never "Payment sent".
- **OCR is a suggestion.** Extracted receipt values are shown as "Suggested from receipt — check this", with a confidence label. The employee must confirm them before saving.
- **Unknown policy is visible, not guessed.** Any unset rule (mileage rate, evidence threshold, approval routing, retention) shows the `ConfigFlag`: "Needs Primely configuration".
- **No exclamation marks, emoji, or blame.** Errors say what happened and how to fix it: "Add a receipt or explain why there isn't one."

## Status vocabulary

Statuses are ALWAYS icon + text + colour, so they never rely on colour alone.

| Status | Label shown | Tone tokens | Icon | Who acts next |
| --- | --- | --- | --- | --- |
| Draft | Draft | `ink-muted` on `status-neutral-soft` | pencil | Employee |
| Submitted | Submitted | `status-review` on `status-review-soft` | clock | Finance |
| Needs information | Needs your input (employee) / Needs information (finance) | `status-action` on `status-action-soft` | question | Employee |
| Resubmitted | Resubmitted | `status-review` on `status-review-soft` | clock + arrow | Finance |
| Approved | Approved · not paid | `status-approved` on `status-approved-soft` | check | Finance (payment) |
| Rejected | Rejected | `status-rejected` on `status-rejected-soft` | cross | Nobody (closed) |
| Payment recorded | Paid | `status-paid` on `status-paid-soft` | double check | Nobody (closed) |
| Withdrawn | Withdrawn | `ink-muted` on `status-neutral-soft` | arrow-back | Nobody (closed) |

`config-flag` (violet) is reserved for missing configuration. It is never used as a claim status.

## Visual foundations

- **Surfaces.** The page is `surface`. Content sits in `surface-raised` panels with a 1px `line` border, `radius-lg` and `shadow-panel`. Read-only and finance-only areas use `surface-sunken`.
- **Colour.** The UI is neutral-first. `primely-navy` is used once per view for the primary action, plus links and active nav. Status hues appear only in badges, banners and summary-tile accents.
- **Type.** One sans family. Page titles use `heading-1`, panel titles `heading-2`, text `body`, and form labels `label`. Helper text and tile definitions use `caption` in `ink-muted`. Money uses `amount` with `font-variant-numeric: tabular-nums`. Claim references (`EXP-2026-00142`) use `reference` in mono.
- **Spacing.** On a 4px grid: `space-3` table cells, `space-4` field gaps and mobile padding, `space-6` desktop panel padding and section gaps, `space-8` page gutters.
- **Focus.** Every interactive element has a visible 2px `primely-navy` outline with a 2px offset. It is never removed.
- **Targets.** Controls are at least 40px tall (44px on touch). On mobile, tables collapse into stacked cards that keep status, reference, date and amount.
- **Privacy cues.** Finance-only notes sit in a `surface-sunken` panel headed with a lock icon and "Finance only — not visible to the employee". Employee-visible messages sit in normal panels.

## Iconography

Use 20px single-stroke line icons (1.75 stroke, round caps) drawn with `currentColor`. No icon set is bundled yet. Previews inline the eight status glyphs and the navigation glyphs as SVG.

## Layout

The layout follows two reference screens of an expense tool. Only their functional cues are used: no branding, layout or connection to that product is implied.
- **App shell.** A `primely-navy` top bar holds the logo and the user menu. Below it, a left sidebar has My claims, New claim, Receipts, Drafts, Awaiting finance, and Reports. Finance queue appears only for finance roles, and Settings and Audit log only for admins. Under 768px the sidebar becomes a bottom bar with four items and a More menu.
- **Employee home.** A greeting comes first, then the date-range picker, then a row of `SummaryTile`s, then a "Claims by status" `StatusCountList` beside the receipt-upload shortcut, then the recent-claims `ClaimTable`.
- **Finance home.** Queue tiles come first, then the `FilterBar`, then the full `ClaimTable`. When nothing matches, show an `EmptyState`.

## Using this system

Load `tokens.css` and `components/bundle.css`. The components are plain HTML + CSS class patterns (prefix `pe-`), and there is no JS bundle. The consumer provides markup, data and behaviour. See each component's README for structure and rules.
